////hi dude////
////javasript
//////
$(function() {
    $('.js-menu-icon').click(function(){
      $(this).next().toggle();
    })
})